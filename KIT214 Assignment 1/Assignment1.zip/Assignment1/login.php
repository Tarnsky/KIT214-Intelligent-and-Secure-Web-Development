<?php
session_start();
?>
<html>
<body>

<form action="verifyLogin.php" method="post">
	Name: <input type="text" name="username"><br>
	Password: <input type="text" name="password"><br>
	<input type="submit">
</form>

</body>
</html> 



